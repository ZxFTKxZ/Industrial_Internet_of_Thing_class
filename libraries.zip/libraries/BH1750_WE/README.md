# BH1750_WE
Arduino Library for the BH1750 / BH1750FVI module. It includes the option to change the measuring time factor.

The example sketch should explain how to use the library. 

Further information can be found here:

https://wolles-elektronikkiste.de/en/bh1750fvi-gy-30-302-ambient-light-sensor (English)

https://wolles-elektronikkiste.de/bh1750fvi-lichtsensormodul (German)

Do you like it? Please rate it with a star!

You want to build on it? No problem. You are free to use it. 
